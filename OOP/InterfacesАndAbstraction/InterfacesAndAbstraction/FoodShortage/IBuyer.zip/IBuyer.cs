﻿namespace FoodShortage
{
    public interface IBuyer : IPerson
    {
        int Food { get; }

        void BuyFood();
    }
}
