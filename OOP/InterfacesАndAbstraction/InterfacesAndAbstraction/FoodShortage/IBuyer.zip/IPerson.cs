﻿namespace FoodShortage
{
    public interface IPerson
    {
        public string Name { get; }
        public int Age { get; }
    }
}
