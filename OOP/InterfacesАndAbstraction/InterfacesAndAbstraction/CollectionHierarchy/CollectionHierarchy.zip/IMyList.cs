﻿namespace CollectionHierarchy
{
    public interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
