﻿namespace BirthdayCelebrations
{
    public interface ILiving
    {
        public string Name { get; }
        public string Birthdate { get; }
    }
}
