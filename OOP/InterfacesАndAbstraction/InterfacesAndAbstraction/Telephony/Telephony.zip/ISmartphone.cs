﻿namespace Telephony
{
    public interface ISmartphone : IPhone
    {
        void Browse(string website);
    }
}
