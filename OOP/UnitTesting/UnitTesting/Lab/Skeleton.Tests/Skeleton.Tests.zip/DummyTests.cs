﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        private Dummy dummy;
        private Dummy deadDummy;
        private Dummy deadDummy2;

        [SetUp]
        public void SetUp()
        {
            dummy = new Dummy(100, 100);
            deadDummy = new Dummy(0, 100);
            deadDummy2 = new Dummy(-100, 100);
        }

        [Test]
        public void Dummy_Should_Lose_Health_After_An_Attack()
        {
            dummy.TakeAttack(10);
            Assert.AreEqual(90, dummy.Health);
        }

        [Test]
        public void A_Dummy_With_0_Health_Should_Throw_Exception_When_Attacked()
        {
            Assert.Throws<InvalidOperationException>(() =>
                {
                    deadDummy.TakeAttack(10);
                }, "Dummy has health of 0."
                );
        }
        [Test]
        public void A_Dummy_With_Negative_Number_Health_Should_Throw_Exception_When_Attacked()
        {
            Assert.Throws<InvalidOperationException>(() =>
                {
                    deadDummy2.TakeAttack(10);
                }, "Dummy has health of -100."
            );
        }

        [Test]

        public void A_Dead_Dummy_Gives_Experience()
        {
            Assert.AreEqual(deadDummy.GiveExperience(), 100);
        }

        [Test]
        public void Alive_Dummy_Should_Throw_Exception_When_Give_Experience_Is_Called()
        {
            Assert.Throws<InvalidOperationException>(() =>
                {
                    dummy.GiveExperience();
                }, "Dummy is not dead"
                );
        }
    }
}