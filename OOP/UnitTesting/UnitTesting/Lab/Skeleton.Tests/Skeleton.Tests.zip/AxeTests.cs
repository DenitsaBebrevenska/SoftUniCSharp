using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        private Axe axe;
        private Axe axe2;
        private Dummy dummy;

        [SetUp]
        public void SetUp()
        {
            axe = new Axe(10, 10);
            axe2 = new Axe(10, 0);
            dummy = new Dummy(10, 10);
        }

        [Test]
        public void Axe_Loses_Durability_After_Each_Attack()
        {
            axe.Attack(dummy);
            Assert.That(axe.DurabilityPoints, Is.EqualTo(9), "Axe Durability doesn`t change after an attack");
        }

        [Test]
        public void A_Weapon_With_0_Durability_Should_Throw_An_Exception_When_Attempting_An_Attack()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                axe2.Attack(dummy);
            }, "Axe`s durability is 0.");

        }
    }
}