﻿namespace NeedForSpeed
{
    public class StartUp
    {
        static void Main()
        {
            Vehicle vehicle = new(100, 100);
            vehicle.Drive(1);
            Console.WriteLine(vehicle.DefaultFuelConsumption);
            Console.WriteLine(vehicle.Fuel);

            Car car = new Car(100, 100);
            car.Drive(1);
            Console.WriteLine(car.DefaultFuelConsumption);
            Console.WriteLine(car.Fuel);

            RaceMotorcycle raceMotorcycle = new(100, 100);
            raceMotorcycle.Drive(1);
            Console.WriteLine(raceMotorcycle.DefaultFuelConsumption);
            Console.WriteLine(raceMotorcycle.Fuel);

            SportCar sportCar = new (100, 100);
            sportCar.Drive(1);
            Console.WriteLine(sportCar.DefaultFuelConsumption);
            Console.WriteLine(sportCar.Fuel);

            FamilyCar familyCar = new (100, 100);
            familyCar.Drive(1);
            Console.WriteLine(familyCar.DefaultFuelConsumption);
            Console.WriteLine(familyCar.Fuel);

            Motorcycle motorcycle = new(100, 100);
            motorcycle.Drive(1);
            Console.WriteLine(motorcycle.DefaultFuelConsumption);
            Console.WriteLine(motorcycle.Fuel);
        }
    }
}
